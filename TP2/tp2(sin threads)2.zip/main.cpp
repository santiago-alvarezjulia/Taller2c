#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <bitset>
#include <sstream>
#include "cache_direct.h"
#include "cache_associative_fifo.h"
#include "cache_associative_lru.h"
#include "cache.h"
#define MEMORY_ADDRESS_SIZE 32
#define DELIMITADOR "="
#define ERROR 1
#define OK 0
#define CANTIDAD_MINIMA_PARAMETROS 3

void run(const char* filename, Cache& cache);

int main(int argc, char* argv[]) {
	if (argc < CANTIDAD_MINIMA_PARAMETROS) {
		std::cerr << "Error en la cantidad de parametros" << std::endl;
		return ERROR;
	}
	
	std::fstream config_file((const char*)argv[1], std::fstream::in);
	if (config_file.fail()) {
		std::cerr << "Error al abrir el archivo" << std::endl;
		return ERROR;
	}
	
	std::map<std::string, std::string> map_config_file;
	std::string line_config_file;
	std::string cache_type;
	do {
		getline(config_file, line_config_file);
		if (line_config_file.empty()) {
			break;
		}
		
		std::size_t pos_delimitador = line_config_file.find(DELIMITADOR);
		std::string key = line_config_file.substr(0, pos_delimitador);
		//el 1 es el largo del delim
		std::string value = line_config_file.substr(pos_delimitador + 1); 
		
		if (key == "cache type") {
			cache_type = value;
		}
		
		map_config_file.insert(std::pair<std::string, std::string>(key, value));
	} while (!line_config_file.empty());
		
	Cache* cache;
	if (cache_type == "associative-lru") {
		cache = new Cache_Associative_Lru ();
	} else if (cache_type == "direct") {
		cache = new Cache_Direct();
	} else {
		cache = new Cache_Associative_Fifo();
	}
	
	cache->set_data(map_config_file);
	cache->print_initialization_data();
	
	for (int i = 2; i < argc; i++) {
		run((const char*)argv[i], *cache);
	}
	
	cache->print_informe();
	config_file.close();
	
	delete cache;
	
	return OK;
}

// abro y leo el archivo .bin con las direcciones de memoria. Para cada direccion
// de memoria, delego en la cache verificar que sea una direccion valida, 
// y procesar la direccion 
void run(const char* filename, Cache& cache){
	std::fstream cpu_file(filename,	std::fstream::in | std::fstream::binary);
	std::string line_cpu_file;
	
	do {
		getline(cpu_file, line_cpu_file);
		if (line_cpu_file.empty()) {
			break;
		}
		
		// conversion de hexa a binario para almacenar en std::bitset
		std::stringstream ss;
		ss << std::hex << line_cpu_file;
		unsigned n;
		ss >> n;
		
		std::bitset<MEMORY_ADDRESS_SIZE> memory_address (n);
		
		std::string binary_address = memory_address.to_string();
		
		// delego en la cache verificar que sea una direccion valida
		int result = cache.validate_memory_address(memory_address, 
			line_cpu_file);
		if (result == ERROR) {
			// la direccion es invalida -> termino el procesamiento del archivo
			cpu_file.close();
			return;
		}
		
		// delego en la cache el procesamiento de la direccion de memoria
		cache.procces_memory_address(binary_address, line_cpu_file);
	} while (!line_cpu_file.empty());
	
	cpu_file.close();
}
